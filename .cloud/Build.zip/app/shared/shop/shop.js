"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Shop = /** @class */ (function () {
    function Shop() {
    }
    return Shop;
}());
exports.Shop = Shop;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2hvcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInNob3AudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTtJQUFBO0lBTUEsQ0FBQztJQUFELFdBQUM7QUFBRCxDQUFDLEFBTkQsSUFNQztBQU5ZLG9CQUFJIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIFNob3Age1xuICAgIGlkOm51bWJlcjtcbiAgICBuYW1lOnN0cmluZztcbiAgICBpbWFnZTpzdHJpbmc7XG4gICAgZGVzY3JpcHRpb246c3RyaW5nO1xuICAgIGxvY2F0aW9uOm9iamVjdDtcbn0iXX0=