"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ShopService = /** @class */ (function () {
    function ShopService() {
    }
    ShopService.prototype.getShops = function () {
    };
    ShopService.prototype.getShopsNearme = function () {
    };
    ShopService.prototype.getShopsHavingProduct = function (product) {
    };
    ShopService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], ShopService);
    return ShopService;
}());
exports.ShopService = ShopService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2hvcC5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsic2hvcC5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQTJDO0FBSTNDO0lBRUU7SUFBZ0IsQ0FBQztJQUVqQiw4QkFBUSxHQUFSO0lBRUEsQ0FBQztJQUNELG9DQUFjLEdBQWQ7SUFFQSxDQUFDO0lBQ0QsMkNBQXFCLEdBQXJCLFVBQXNCLE9BQWU7SUFFckMsQ0FBQztJQVpVLFdBQVc7UUFEdkIsaUJBQVUsRUFBRTs7T0FDQSxXQUFXLENBZXZCO0lBQUQsa0JBQUM7Q0FBQSxBQWZELElBZUM7QUFmWSxrQ0FBVyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFByb2R1Y3QgfSBmcm9tICd+L3NoYXJlZC9wcm9kdWN0L3Byb2R1Y3QnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgU2hvcFNlcnZpY2Uge1xuXG4gIGNvbnN0cnVjdG9yKCkgeyB9XG5cbiAgZ2V0U2hvcHMoKXtcblxuICB9XG4gIGdldFNob3BzTmVhcm1lKCl7XG5cbiAgfVxuICBnZXRTaG9wc0hhdmluZ1Byb2R1Y3QocHJvZHVjdDpQcm9kdWN0KXtcblxuICB9XG5cblxufVxuIl19