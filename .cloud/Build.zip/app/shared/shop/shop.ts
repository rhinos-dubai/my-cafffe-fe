export class Shop {
    id:number;
    name:string;
    image:string;
    description:string;
    location:object;
}