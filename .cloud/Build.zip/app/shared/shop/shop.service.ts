import { Injectable } from '@angular/core';
import { Product } from '~/shared/product/product';

@Injectable()
export class ShopService {

  constructor() { }

  getShops(){

  }
  getShopsNearme(){

  }
  getShopsHavingProduct(product:Product){

  }


}
