"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Option = /** @class */ (function () {
    function Option(name, selected, price) {
    }
    return Option;
}());
exports.Option = Option;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3B0aW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsib3B0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUE7SUFDSSxnQkFDSSxJQUFXLEVBQ1gsUUFBZ0IsRUFDaEIsS0FBWTtJQUNkLENBQUM7SUFDUCxhQUFDO0FBQUQsQ0FBQyxBQU5ELElBTUM7QUFOWSx3QkFBTSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBPcHRpb24ge1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBuYW1lOnN0cmluZyxcbiAgICAgICAgc2VsZWN0ZWQ6Ym9vbGVhbixcbiAgICAgICAgcHJpY2U6bnVtYmVyLFxuICAgICl7fVxufSJdfQ==