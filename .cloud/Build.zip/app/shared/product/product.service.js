"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/common/http");
var rxjs_1 = require("rxjs");
var operators_1 = require("rxjs/operators");
var config_1 = require("~/shared/config");
var product_1 = require("~/shared/product/product");
var ProductService = /** @class */ (function () {
    function ProductService(http, zone) {
        this.http = http;
        this.zone = zone;
    }
    ProductService.prototype.getCategories = function (level) {
    };
    ProductService.prototype.getProducts = function (category) {
        var _this = this;
        var params = new http_1.HttpParams();
        params.append("sort", "{\"_kmd.lmt\": -1}");
        return this.http.get(config_1.Config.apiUrl, {
            headers: this.getCommonHeaders(),
            params: params,
        })
            .pipe(operators_1.map(function (data) {
            data.forEach(function (grocery) {
                _this.allItems.push(new product_1.Product(grocery.id, grocery.name, grocery.options || [], grocery.addons || []));
            });
        }), operators_1.catchError(this.handleErrors));
    };
    ProductService.prototype.getCommonHeaders = function () {
        return new http_1.HttpHeaders({
            "Content-Type": "application/json",
            "Authorization": "Kinvey " + config_1.Config.token,
        });
    };
    ProductService.prototype.handleErrors = function (error) {
        console.log(error);
        return rxjs_1.throwError(error);
    };
    ProductService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [http_1.HttpClient, core_1.NgZone])
    ], ProductService);
    return ProductService;
}());
exports.ProductService = ProductService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZHVjdC5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicHJvZHVjdC5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQW1EO0FBQ25ELDZDQUs4QjtBQUU5Qiw2QkFBOEQ7QUFDOUQsNENBQWlEO0FBRWpELDBDQUF5QztBQUN6QyxvREFBbUQ7QUFHbkQ7SUFFRSx3QkFBb0IsSUFBZ0IsRUFBVSxJQUFZO1FBQXRDLFNBQUksR0FBSixJQUFJLENBQVk7UUFBVSxTQUFJLEdBQUosSUFBSSxDQUFRO0lBQUksQ0FBQztJQUcvRCxzQ0FBYSxHQUFiLFVBQWMsS0FBWTtJQUUxQixDQUFDO0lBQ0Qsb0NBQVcsR0FBWCxVQUFZLFFBQWU7UUFBM0IsaUJBd0JDO1FBdkJDLElBQU0sTUFBTSxHQUFHLElBQUksaUJBQVUsRUFBRSxDQUFDO1FBQ2hDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLG9CQUFvQixDQUFDLENBQUM7UUFFNUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQU0sQ0FBQyxNQUFNLEVBQUU7WUFDbEMsT0FBTyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUNoQyxNQUFNLFFBQUE7U0FDUCxDQUFDO2FBQ0QsSUFBSSxDQUNILGVBQUcsQ0FBQyxVQUFDLElBQVc7WUFDZCxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUMsT0FBTztnQkFDbkIsS0FBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQ2hCLElBQUksaUJBQU8sQ0FDVCxPQUFPLENBQUMsRUFBRSxFQUNWLE9BQU8sQ0FBQyxJQUFJLEVBQ1osT0FBTyxDQUFDLE9BQU8sSUFBSSxFQUFFLEVBQ3JCLE9BQU8sQ0FBQyxNQUFNLElBQUksRUFBRSxDQUNyQixDQUNGLENBQUM7WUFFSixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxFQUNGLHNCQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUM5QixDQUFDO0lBQ0osQ0FBQztJQUVPLHlDQUFnQixHQUF4QjtRQUNFLE1BQU0sQ0FBQyxJQUFJLGtCQUFXLENBQUM7WUFDckIsY0FBYyxFQUFFLGtCQUFrQjtZQUNsQyxlQUFlLEVBQUUsU0FBUyxHQUFHLGVBQU0sQ0FBQyxLQUFLO1NBQzFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTyxxQ0FBWSxHQUFwQixVQUFxQixLQUF3QjtRQUMzQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ25CLE1BQU0sQ0FBQyxpQkFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUE1Q1UsY0FBYztRQUQxQixpQkFBVSxFQUFFO3lDQUdlLGlCQUFVLEVBQWdCLGFBQU07T0FGL0MsY0FBYyxDQStDMUI7SUFBRCxxQkFBQztDQUFBLEFBL0NELElBK0NDO0FBL0NZLHdDQUFjIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgTmdab25lIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge1xuICBIdHRwQ2xpZW50LFxuICBIdHRwSGVhZGVycyxcbiAgSHR0cEVycm9yUmVzcG9uc2UsXG4gIEh0dHBQYXJhbXMsXG59IGZyb20gXCJAYW5ndWxhci9jb21tb24vaHR0cFwiO1xuXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBCZWhhdmlvclN1YmplY3QgLHRocm93RXJyb3J9IGZyb20gXCJyeGpzXCI7XG5pbXBvcnQgeyBtYXAsIGNhdGNoRXJyb3IgfSBmcm9tIFwicnhqcy9vcGVyYXRvcnNcIjtcblxuaW1wb3J0IHsgQ29uZmlnIH0gZnJvbSBcIn4vc2hhcmVkL2NvbmZpZ1wiO1xuaW1wb3J0IHsgUHJvZHVjdCB9IGZyb20gJ34vc2hhcmVkL3Byb2R1Y3QvcHJvZHVjdCc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBQcm9kdWN0U2VydmljZSB7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50LCBwcml2YXRlIHpvbmU6IE5nWm9uZSkgeyB9XG4gIGFsbEl0ZW1zOkFycmF5PFByb2R1Y3Q+O1xuXG4gIGdldENhdGVnb3JpZXMobGV2ZWw6bnVtYmVyKXtcbiAgICBcbiAgfVxuICBnZXRQcm9kdWN0cyhjYXRlZ29yeTpudW1iZXIpe1xuICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKCk7XG4gICAgcGFyYW1zLmFwcGVuZChcInNvcnRcIiwgXCJ7XFxcIl9rbWQubG10XFxcIjogLTF9XCIpO1xuXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQoQ29uZmlnLmFwaVVybCwge1xuICAgICAgaGVhZGVyczogdGhpcy5nZXRDb21tb25IZWFkZXJzKCksXG4gICAgICBwYXJhbXMsXG4gICAgfSlcbiAgICAucGlwZShcbiAgICAgIG1hcCgoZGF0YTogYW55W10pID0+IHtcbiAgICAgICAgZGF0YS5mb3JFYWNoKChncm9jZXJ5KSA9PiB7XG4gICAgICAgICAgdGhpcy5hbGxJdGVtcy5wdXNoKFxuICAgICAgICAgICAgbmV3IFByb2R1Y3QoXG4gICAgICAgICAgICAgIGdyb2NlcnkuaWQsXG4gICAgICAgICAgICAgIGdyb2NlcnkubmFtZSxcbiAgICAgICAgICAgICAgZ3JvY2VyeS5vcHRpb25zIHx8IFtdLFxuICAgICAgICAgICAgICBncm9jZXJ5LmFkZG9ucyB8fCBbXVxuICAgICAgICAgICAgKVxuICAgICAgICAgICk7XG4gICAgICAgICAgIFxuICAgICAgICB9KTtcbiAgICAgIH0pLFxuICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9ycylcbiAgICApO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRDb21tb25IZWFkZXJzKCkge1xuICAgIHJldHVybiBuZXcgSHR0cEhlYWRlcnMoe1xuICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICBcIkF1dGhvcml6YXRpb25cIjogXCJLaW52ZXkgXCIgKyBDb25maWcudG9rZW4sXG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGhhbmRsZUVycm9ycyhlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpIHtcbiAgICBjb25zb2xlLmxvZyhlcnJvcik7XG4gICAgcmV0dXJuIHRocm93RXJyb3IoZXJyb3IpO1xuICB9XG5cblxufVxuIl19