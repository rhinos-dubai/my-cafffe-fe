export class Product {

   constructor( 
       id:string,
       name:string,
       optionGroups:Array<any>,
       addonGroups:Array<any>,
       price?:number
   ){}
}