export class Option {
    constructor(
        name:string,
        selected:boolean,
        price:number,
    ){}
}