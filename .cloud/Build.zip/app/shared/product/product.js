"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Product = /** @class */ (function () {
    function Product(id, name, optionGroups, addonGroups, price) {
    }
    return Product;
}());
exports.Product = Product;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZHVjdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInByb2R1Y3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTtJQUVHLGlCQUNJLEVBQVMsRUFDVCxJQUFXLEVBQ1gsWUFBdUIsRUFDdkIsV0FBc0IsRUFDdEIsS0FBYTtJQUNmLENBQUM7SUFDTixjQUFDO0FBQUQsQ0FBQyxBQVRELElBU0M7QUFUWSwwQkFBTyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBQcm9kdWN0IHtcblxuICAgY29uc3RydWN0b3IoIFxuICAgICAgIGlkOnN0cmluZyxcbiAgICAgICBuYW1lOnN0cmluZyxcbiAgICAgICBvcHRpb25Hcm91cHM6QXJyYXk8YW55PixcbiAgICAgICBhZGRvbkdyb3VwczpBcnJheTxhbnk+LFxuICAgICAgIHByaWNlPzpudW1iZXJcbiAgICl7fVxufSJdfQ==