import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'shop-list',
  templateUrl: './shop-list.component.html',
  styleUrls: ['./shop-list.component.scss']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
